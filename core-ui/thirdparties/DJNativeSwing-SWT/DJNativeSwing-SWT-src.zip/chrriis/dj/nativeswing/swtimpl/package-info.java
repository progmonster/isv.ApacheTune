/*
 * Christopher Deckers (chrriis@nextencia.net)
 * http://www.nextencia.net
 *
 * See the file "readme.txt" for information on usage and redistribution of
 * this file, and for a DISCLAIMER OF ALL WARRANTIES.
 */

/**
 * The SWT-based implementation using the Native Swing framework.
 * @author Christopher Deckers
 */
package chrriis.dj.nativeswing.swtimpl;
