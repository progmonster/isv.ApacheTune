package chrriis.dj.nativeswing.swtimpl;

interface NoSerializationTestMessage {

}
